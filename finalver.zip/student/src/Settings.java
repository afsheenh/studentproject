

import java.awt.Dimension;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Settings {
    public static Dimension getScreenSize(){
        Dimension d=Toolkit.getDefaultToolkit().getScreenSize();
        return d;   
    }//getScreenSize() closed
    
    public static Connection getDBConnection(){
        Connection con;
        try{
        	
           /* Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:student");
            return con;*/
            String database="D://studentproj//student.mdb";//Here database exists in the current directory  
            
            String url="jdbc:odbc:Driver={Microsoft Access Driver (*.mdb)}; DBQ=" + database + ";DriverID=22;READONLY=true";  
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");  
            Connection c=DriverManager.getConnection(url);  
            return c;
}catch(Exception ex){
            return null;
        }
    }
}//class closed
